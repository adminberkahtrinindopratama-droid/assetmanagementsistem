import DashboardClient from "./dashboard-client";
import { requireChatGPTUser } from "./chatgpt-auth";

export const dynamic = "force-dynamic";

export default async function Page() {
  const user = await requireChatGPTUser("/");
  return <DashboardClient user={{displayName:user.displayName,email:user.email}} />;
}
