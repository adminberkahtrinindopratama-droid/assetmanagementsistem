import { env } from "cloudflare:workers";
import { NextRequest, NextResponse } from "next/server";
import { getChatGPTUser } from "@/app/chatgpt-auth";

export const dynamic = "force-dynamic";

export async function GET(_request:NextRequest,context:{params:Promise<{key:string}>}){
  try{
    if(!await getChatGPTUser())return NextResponse.json({error:"Anda harus login."},{status:401});
    if(!env.BUCKET)return NextResponse.json({error:"Penyimpanan gambar belum tersedia."},{status:503});
    const {key}=await context.params;
    if(!/^product-[a-f0-9-]+\.(jpg|png|webp)$/.test(key))return NextResponse.json({error:"Gambar tidak valid."},{status:400});
    const object=await env.BUCKET.get(key);
    if(!object)return NextResponse.json({error:"Gambar tidak ditemukan."},{status:404});
    const headers=new Headers();
    object.writeHttpMetadata(headers);
    headers.set("etag",object.httpEtag);
    headers.set("Cache-Control","private, max-age=86400");
    return new Response(object.body,{headers});
  }catch{
    return NextResponse.json({error:"Gambar belum dapat dimuat."},{status:500});
  }
}
