import { env } from "cloudflare:workers";
import { NextRequest, NextResponse } from "next/server";
import { getChatGPTUser } from "@/app/chatgpt-auth";

export const dynamic = "force-dynamic";

const allowedTypes:Record<string,string>={
  "image/jpeg":"jpg",
  "image/png":"png",
  "image/webp":"webp",
};

export async function POST(request:NextRequest){
  try{
    if(!await getChatGPTUser())return NextResponse.json({error:"Anda harus login."},{status:401});
    if(!env.BUCKET)return NextResponse.json({error:"Penyimpanan gambar belum tersedia."},{status:503});
    const form=await request.formData();
    const image=form.get("image");
    if(!(image instanceof File))return NextResponse.json({error:"Pilih gambar produk terlebih dahulu."},{status:400});
    const extension=allowedTypes[image.type];
    if(!extension)return NextResponse.json({error:"Gunakan gambar JPG, PNG, atau WebP."},{status:400});
    if(image.size>5*1024*1024)return NextResponse.json({error:"Ukuran gambar maksimal 5 MB."},{status:400});
    const key=`product-${crypto.randomUUID()}.${extension}`;
    await env.BUCKET.put(key,image.stream(),{httpMetadata:{contentType:image.type},customMetadata:{originalName:image.name}});
    return NextResponse.json({url:`/api/product-images/${key}`},{status:201});
  }catch{
    return NextResponse.json({error:"Gambar gagal diunggah. Silakan coba kembali."},{status:500});
  }
}
