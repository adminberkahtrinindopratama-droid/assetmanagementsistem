import { NextRequest, NextResponse } from "next/server";
import { deleteRecord, updateRecord } from "@/db/records";
import { getChatGPTUser } from "@/app/chatgpt-auth";

export const dynamic = "force-dynamic";

export async function PUT(request:NextRequest, context:{params:Promise<{id:string}>}) {
  try {
    if(!await getChatGPTUser()) return NextResponse.json({error:"Anda harus login."},{status:401});
    const {id} = await context.params;
    const recordId = Number(id);
    const body = await request.json() as {reference?:unknown;fields?:unknown};
    if(!Number.isInteger(recordId) || typeof body.reference!=="string" || !Array.isArray(body.fields) || body.fields.some(x=>typeof x!=="string")) {
      return NextResponse.json({error:"Data belum lengkap."},{status:400});
    }
    return NextResponse.json({record:await updateRecord(recordId,body.reference.trim(),body.fields.map(x=>x.trim()))});
  } catch {
    return NextResponse.json({error:"Data gagal diubah."},{status:500});
  }
}

export async function DELETE(_request:NextRequest, context:{params:Promise<{id:string}>}) {
  try {
    if(!await getChatGPTUser()) return NextResponse.json({error:"Anda harus login."},{status:401});
    const {id} = await context.params;
    const recordId = Number(id);
    if(!Number.isInteger(recordId)) return NextResponse.json({error:"ID tidak valid."},{status:400});
    await deleteRecord(recordId);
    return NextResponse.json({deleted:true});
  } catch {
    return NextResponse.json({error:"Data gagal dihapus."},{status:500});
  }
}
