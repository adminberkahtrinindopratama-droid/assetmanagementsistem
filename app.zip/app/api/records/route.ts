import { NextRequest, NextResponse } from "next/server";
import { createRecord, listRecords } from "@/db/records";
import { getChatGPTUser } from "@/app/chatgpt-auth";

export const dynamic = "force-dynamic";

export async function GET(request:NextRequest) {
  try {
    if(!await getChatGPTUser()) return NextResponse.json({error:"Anda harus login."},{status:401});
    const section = request.nextUrl.searchParams.get("section") || undefined;
    return NextResponse.json({records:await listRecords(section)},{headers:{"Cache-Control":"no-store, no-cache, must-revalidate"}});
  } catch {
    return NextResponse.json({error:"Data belum dapat dimuat."},{status:500});
  }
}

export async function POST(request:NextRequest) {
  try {
    if(!await getChatGPTUser()) return NextResponse.json({error:"Anda harus login."},{status:401});
    const body = await request.json() as {section?:unknown;reference?:unknown;fields?:unknown};
    if(typeof body.section!=="string" || typeof body.reference!=="string" || !Array.isArray(body.fields) || body.fields.some(x=>typeof x!=="string")) {
      return NextResponse.json({error:"Data belum lengkap."},{status:400});
    }
    const record = await createRecord(body.section.trim(), body.reference.trim(), body.fields.map(x=>x.trim()));
    return NextResponse.json({record},{status:201});
  } catch {
    return NextResponse.json({error:"Data gagal disimpan. Silakan coba kembali."},{status:500});
  }
}
