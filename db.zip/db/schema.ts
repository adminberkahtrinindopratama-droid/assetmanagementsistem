import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const records = sqliteTable("records", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  section: text("section").notNull(),
  reference: text("reference").notNull(),
  fields: text("fields").notNull(),
  createdAt: text("created_at").notNull(),
}, (table) => ({
  sectionIndex: index("idx_records_section").on(table.section),
}));
