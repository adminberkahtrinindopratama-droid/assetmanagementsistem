import { env } from "cloudflare:workers";

export type StoredRecord = {
  id: number;
  section: string;
  reference: string;
  fields: string[];
  createdAt: string;
};

function database() {
  if (!env.DB) throw new Error("Database belum tersedia");
  return env.DB;
}

export async function listRecords(section?: string): Promise<StoredRecord[]> {
  const statement = section
    ? database().prepare("SELECT id, section, reference, fields, created_at AS createdAt FROM records WHERE section = ? ORDER BY id DESC").bind(section)
    : database().prepare("SELECT id, section, reference, fields, created_at AS createdAt FROM records ORDER BY id DESC");
  const result = await statement.all<{id:number;section:string;reference:string;fields:string;createdAt:string}>();
  return (result.results ?? []).map(row => ({...row, fields: JSON.parse(row.fields) as string[]}));
}

export async function createRecord(section:string, reference:string, fields:string[]) {
  const createdAt = new Date().toISOString();
  const result = await database().prepare(
    "INSERT INTO records (section, reference, fields, created_at) VALUES (?, ?, ?, ?) RETURNING id"
  ).bind(section, reference, JSON.stringify(fields), createdAt).first<{id:number}>();
  if (!result?.id) throw new Error("Data gagal disimpan");
  return {id:result.id, section, reference, fields, createdAt};
}

export async function updateRecord(id:number, reference:string, fields:string[]) {
  const result = await database().prepare(
    "UPDATE records SET reference = ?, fields = ? WHERE id = ? RETURNING section, created_at AS createdAt"
  ).bind(reference, JSON.stringify(fields), id).first<{section:string;createdAt:string}>();
  if (!result) throw new Error("Data tidak ditemukan");
  return {id, section:result.section, reference, fields, createdAt:result.createdAt};
}

export async function deleteRecord(id:number) {
  const result = await database().prepare("DELETE FROM records WHERE id = ? RETURNING id").bind(id).first<{id:number}>();
  if (!result) throw new Error("Data tidak ditemukan");
  return result.id;
}
